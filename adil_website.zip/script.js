let score = 0;
const box = document.getElementById("game-box");
const scoreDisplay = document.getElementById("score");
const winMessage = document.getElementById("win-message");

function moveBox() {
  const x = Math.random() * 80;
  const y = Math.random() * 80;
  box.style.top = y + "vh";
  box.style.left = x + "vw";
  box.style.position = "absolute";
}

box.addEventListener("click", () => {
  score++;
  scoreDisplay.textContent = "Score: " + score;
  moveBox();

  if (score >= 5) {
    winMessage.textContent = "🎉 You won the game!";
    box.style.display = "none";
  }
});

moveBox();
